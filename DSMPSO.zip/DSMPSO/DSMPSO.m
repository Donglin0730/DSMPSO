
function [Best_pos,Best_score,curve]=DSMPSO(pop,Max_FEs,lb,ub,dim,fobj)
FEs = 0;
Dim = dim;
Vmax=0.9;
Vmin = -0.4;
sizepop = pop;
neighborhood_size =2;
opint=0.45;
Fmax = 0.9;
Fmin = 0.1;
popsubsize= 0.4;
it = 0;
if(max(size(ub)) == 1)
    ub = ub.*ones(1,dim);
    lb = lb.*ones(1,dim);
end
Range = ones(sizepop,1)*(ub-lb);
pop = rand(sizepop,Dim).*Range + ones(sizepop,1)*lb;
V = rand(sizepop,Dim)*(Vmax-Vmin) + Vmin;
fitness = zeros(sizepop,1);
for i=1:sizepop
    fitness(i,:) =fobj(pop(i,:));
end
FEs =FEs+size(pop,1);
[bestf, bestindex]=min(fitness);
zbest=pop(bestindex,:);
pbest=pop;
fitnesspbest=fitness;
fitnesszbest=bestf;
[worstf,worstindex]=max(fitness);
zworst =pop(worstindex,:);
fitnesszworst = worstf;
select_size=3;
best_v = zeros(select_size,dim);
[~,sort_index]=sort(fitness);
for i = 1:select_size
    best_v(i,:) = pop(sort_index(i),:);
end
best_vtemp = best_v;
StapMax = 10;
Exploration = -1;
Balance=0;
Exploitation=1;
StagG = 0;
num_gw=0;
num_gb=0;
observ_point = ceil(pop*opint);
for i = 1: size(pop,1)
    Digb = Cal_sequence(pop(i,:),zbest);
    Digw = Cal_sequence(pop(i,:),zworst);
    if  Digb>Digw
        num_gw = num_gw+1;
    else
        num_gb = num_gb+1;
    end
    total_num = num_gw - num_gb;
    if total_num>=observ_point
        State = Exploration;
    elseif -observ_point<total_num && total_num<observ_point
        State = Balance;
    elseif  total_num<=-observ_point
        State = Exploitation;
    end
end
while  FEs <Max_FEs
    if StagG == StapMax
        for i = 1: size(pop,1)
            Digb = Cal_sequence(pop(i,:),zbest);
            Digw = Cal_sequence(pop(i,:),zworst);
            if  Digb>Digw
                num_gw = num_gw+1;
            else
                num_gb = num_gb+1;
            end
            total_num = num_gw - num_gb;
            if total_num>observ_point
                State = Exploration;
            elseif -observ_point<=total_num && total_num<=observ_point
                State = Balance;
            elseif  total_num<-observ_point
                State = Exploitation;
            end
        end
        StagG = 0;
    end
    if FEs==sizepop
        y=rand;
    end
    belta=0.8;
    if y<belta
        y= sin(((1-belta)/(1+belta)-pi*y/belta)*(10^5));
    else
        y=sin(((1-belta)/(1+belta)-pi*(1-y)/belta)*(10^5));
    end
    if y<0
        y=rand;
    end
    c1= 2.5-y*(FEs/Max_FEs);
    c2= 0.5+y*(FEs/Max_FEs);
    w= 0.9-0.5*FEs/Max_FEs;
    if State == Exploration
        for i=1:size(pop,1)
            winidxmask = repmat((1:size(pop,1))',1,dim);
            winidx = winidxmask + ceil(rand(size(pop,1),dim).*(size(pop,1)-winidxmask));
            pwin = pbest;
            for j = 1:dim
                pwin(:,j) = pbest(winidx(:,j),j);
            end
            if fobj(pwin(i,:))<fitnesspbest(i)
                pt= pwin(i,:);
            else
                pt = pbest(i,:);
            end
            V(i,:) = w*V(i,:)+c1*rand(1,dim).*(pt-pop(i,:))+c2*rand(1,dim).*(zbest - pop(i,:));
            pop(i,:)=V(i,:) +pop(i,:);
            
        end
    elseif  State == Balance
        for i=1:size(pop,1)
            V(i,:) = w*V(i,:)+c1*rand(1,dim).*(pbest(i,:)-pop(i,:))+c2*rand(1,dim).*(mean(pbest) - pop(i,:));
            pop(i,:)=V(i,:) +pop(i,:);
        end
    elseif  State == Exploitation
        for i=1:size(pop,1)
            V(i,:) = w*V(i,:)+c1*rand(1,dim).*(pbest(i,:)-pop(i,:))+c2*rand(1,dim).*(zbest - pop(i,:));
            pop(i,:)=V(i,:) +pbest(i,:);
        end
    end
    for i=1:sizepop
        for k=1:Dim
            if pop(i,k)>ub(k)
                pop(i,k)=rand*ub(k);
            end
            if pop(i,k)<lb(k)
                pop(i,k)=rand*lb(k);
            end
        end
        fitness(i,:) =fobj(pop(i,:));
         FEs =FEs+1;
        if fitness(i) < fitnesspbest(i)
            pbest(i,:) = pop(i,:);
            fitnesspbest(i) = fitness(i);
        end
        if fitness(i) < fitnesszbest
            zbest = pop(i,:);
            fitnesszbest = fitness(i);
        end
    end
    [~,winindex]=sort(fitness);
    
    for i = 1:ceil(size(pop,1)*popsubsize)
        index = randperm(size(pop,1),3);
        if rand<0.5
            S = zbest + rand.*(pop(index(1),:)-pop(i,:)) + rand.*(pop(index(2),:)-pop(index(3),:));
        else
            fop = fobj( pop(i,:));
             FEs =FEs+1;
            F = Fmax - (Fmax - Fmin)*((fop-fitnesszbest)/(fitnesszbest+fitnesszworst));
             neighbors = mod((i-neighborhood_size:i+neighborhood_size)-1, ceil(size(pop,1)*popsubsize)) + 1;
             personal_best_scores = fitness(neighbors);
              [~, idx] = min(personal_best_scores);
            % random_index = randi(length(neighbors)); 
            S = pop(neighbors(idx),:) + F.*(pop(index(1),:)-pop(i,:)) + F.*((pop(index(2),:)-pop(index(3),:)));
        end
        sf = fobj(S);
         FEs =FEs+1;
        if sf<fitness(winindex(i))
            pop(winindex(i),:) = S;
            if sf < fitnesspbest(winindex(i))
                pbest(winindex(i),:) = S;
                fitnesspbest(winindex(i)) = sf;
            end 
            if sf< fitnesszbest
                zbest = S;
                fitnesszbest = sf;
            end
        end
    end
    raindex = randperm(sizepop,1);
    zbestemp = zbest+rand(1,dim).*(zbest - pbest(raindex,:));
    tf =fobj(zbestemp);
    fitnesszbest;
    if tf<fitnesszbest
        zbest = zbestemp;
        fitnesszbest = tf;
    end
    [worstf,worstindex]=max(fitnesspbest);
    zworst =pop(worstindex,:);
    fitnesszworst = worstf;
    StagG = StagG +1;
    num_gw = 0;
    num_gb = 0;
    it =it+1;
    curve(it) = fitnesszbest;
end
Best_pos = zbest;
Best_score = fitnesszbest;
end



