
function count_similar= Cal_sequence(x1,x2)
pop_seq = convert_to_dna(x1);         
other_seq = convert_to_dna(x2);       
numlen = length(pop_seq);
if length(pop_seq) ~= length(other_seq)
    error('Sequences must be of equal length.');
end
count_similar = 0;
seq11 = upper(pop_seq);
seq22= upper(other_seq);
for i = 1:length(seq11)
    if seq11(i) == seq22(i)
        count_similar = count_similar + 1;
    end
end
end
function dna_sequence= convert_to_dna(sequence)
dna_sequence = ' ';
max_sequence = max(sequence);
min_sequence=min(sequence);
Ave_interval = (max_sequence-min_sequence)/4;
interv = [min_sequence,...                  
    min_sequence+Ave_interval,...         
    min_sequence+Ave_interval*2,...      
    min_sequence+Ave_interval*3,...       
    max_sequence] ;                            
for i = 1:size(sequence,2)
    if sequence(i) >= interv(1) && sequence(i) <= interv(2)
        dna_sequence = strcat(dna_sequence, 'C');
    elseif sequence(i) > interv(2) && sequence(i) <= interv(3)
        dna_sequence = strcat(dna_sequence, 'T');
    elseif  sequence(i) > interv(3) && sequence(i)<=  interv(4)
        dna_sequence = strcat(dna_sequence, 'A');
    elseif  sequence(i) > interv(4) && sequence(i)<=  max_sequence
        dna_sequence = strcat(dna_sequence, 'G');
    end
end
end
